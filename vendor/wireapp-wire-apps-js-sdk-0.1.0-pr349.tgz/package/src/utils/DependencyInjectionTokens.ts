/*
 * Wire
 * Copyright (C) 2025 Wire Swiss GmbH
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see http://www.gnu.org/licenses/.
 */

export const WIRE_API_HOST = 'WIRE_API_HOST'
export const WIRE_SDK_API_TOKEN = 'WIRE_SDK_API_TOKEN'
export const WIRE_CRYPTOGRAPHY_STORAGE_KEY = 'WIRE_CRYPTOGRAPHY_STORAGE_KEY'
export const WIRE_STORAGE_PATH = 'WIRE_STORAGE_PATH'

export const WIRE_EVENTS_HANDLER = 'WIRE_EVENTS_HANDLER'

export const EVENT_PROCESSOR = 'EVENT_PROCESSOR'
