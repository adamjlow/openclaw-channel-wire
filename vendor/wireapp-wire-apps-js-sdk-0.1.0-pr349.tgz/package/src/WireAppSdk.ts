/*
 * Wire
 * Copyright (C) 2025 Wire Swiss GmbH
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see http://www.gnu.org/licenses/.
 */

import 'reflect-metadata'
import './core/event/processors.index.js'
import {mkdirSync} from 'node:fs'
import {resolve} from 'node:path'
import {CoreCryptoService} from './core/CoreCryptoService.js'
import {
  WIRE_API_HOST,
  WIRE_CRYPTOGRAPHY_STORAGE_KEY,
  WIRE_EVENTS_HANDLER,
  WIRE_SDK_API_TOKEN,
  WIRE_STORAGE_PATH
} from './utils/DependencyInjectionTokens.js'
import {WebSocketClient} from './core/WebSocketClient.js'
import {WireEventsHandler} from './core/WireEventsHandler.js'
import {DatabaseService} from './db/DatabaseService.js'
import {container} from 'tsyringe'
import type {Logger} from './utils/logger/Logger.js'
import {LoggerFactory} from './utils/logger/LoggerFactory.js'
import {ConsoleLogger} from './utils/logger/ConsoleLogger.js'
import {ConversationService} from './api/ConversationService.js'
import {AppProperties} from './service/AppProperties.js'
import {DEFAULT_STORAGE_PATH, getCryptographyStoragePath} from './utils/StoragePaths.js'
import type {WireAppSdkOptions} from './WireAppSdkOptions.js'
import type {BackendConnectionListener} from './core/BackendConnectionListener.js'
import {InvalidParameterError, UnknownError} from './exception/WireException.js'
import {SelfService} from './api/SelfService.js'
import {WireApplicationManager} from './core/WireApplicationManager.js'

export class WireAppSdk {
  private readonly CRYPTOGRAPHY_STORAGE_KEY_BYTES = 32
  private apiToken: string
  private apiHost: string
  private cryptographyStorageKey: Uint8Array
  private storagePath: string

  private isShuttingDown = false
  private readonly shouldRegisterExitHandlers: boolean

  // SIGINT: Ctrl+C in terminal
  private readonly onSigint = () => this.handleExit('SIGINT', 0)

  // SIGTERM: Termination signal (e.g., from Docker, Kubernetes)
  private readonly onSigterm = () => this.handleExit('SIGTERM', 0)

  // Errors always exit with a failure code, so supervisors restart the process
  private readonly onUncaughtException = (error: Error) => {
    this.logger.error('Uncaught exception:', error)
    this.handleExit('uncaughtException', 1)
  }

  private readonly onUnhandledRejection = (reason: unknown) => {
    this.logger.error('Unhandled rejection:', reason)
    this.handleExit('unhandledRejection', 1)
  }

  private isWebSocketRunning: boolean = false
  private webSocketClient?: WebSocketClient
  private conversationService?: ConversationService
  private appProperties?: AppProperties

  private wireEventsHandler: WireEventsHandler
  private logger: Logger

  private constructor(
    apiToken: string,
    apiHost: string,
    cryptographyStorageKey: Uint8Array,
    wireEventsHandler: WireEventsHandler,
    logger?: Logger,
    options: WireAppSdkOptions = {}
  ) {
    if (cryptographyStorageKey.length !== this.CRYPTOGRAPHY_STORAGE_KEY_BYTES) {
      throw new InvalidParameterError(
        `cryptographyStorageKey must be exactly ${this.CRYPTOGRAPHY_STORAGE_KEY_BYTES} bytes long`
      )
    }

    if (options.storagePath !== undefined && options.storagePath.trim() === '') {
      throw new InvalidParameterError('storagePath must not be empty; omit it to use the default ./storage')
    }

    this.apiToken = apiToken
    this.apiHost = apiHost
    this.cryptographyStorageKey = cryptographyStorageKey
    // Resolve once, so a later process.chdir() cannot move the storage while the SDK is running.
    this.storagePath = resolve(options.storagePath ?? DEFAULT_STORAGE_PATH)
    this.wireEventsHandler = wireEventsHandler
    this.shouldRegisterExitHandlers = options.registerExitHandlers ?? true
    LoggerFactory.setRootLogger(logger ?? new ConsoleLogger())
    this.logger = LoggerFactory.getLogger(this.constructor.name)
  }

  /**
   * Creates and initializes the SDK.
   *
   * @param apiToken API token of the Wire application
   * @param apiHost Base URL of the Wire backend API
   * @param cryptographyStorageKey 32-byte key used to encrypt the local cryptographic storage
   * @param wireEventsHandler Handler receiving the events of the application
   * @param logger Optional logger, defaults to {@link ConsoleLogger}
   * @param options Optional settings, see {@link WireAppSdkOptions}
   */
  static async create(
    apiToken: string,
    apiHost: string,
    cryptographyStorageKey: Uint8Array,
    wireEventsHandler: WireEventsHandler,
    logger?: Logger,
    options?: WireAppSdkOptions
  ): Promise<WireAppSdk> {
    const wireAppSdk = new WireAppSdk(apiToken, apiHost, cryptographyStorageKey, wireEventsHandler, logger, options)

    wireAppSdk.registerExitHandlers()
    try {
      await wireAppSdk.init()
    } catch (error) {
      wireAppSdk.removeExitHandlers()
      throw error
    }
    return wireAppSdk
  }

  private async init() {
    this.prepareStorage()
    this.configureDependencyTokens()

    // Save cookie from constructor parameter only at first application start.
    // Once BE provides new token, the one stored in `apiToken` will be obsolete.
    this.appProperties = container.resolve(AppProperties)
    this.appProperties.saveBackendCookieIfMissing(this.apiToken)

    await this.configureApplicationIdentity()
    this.resolveRuntimeDependencies()

    await this.initCryptoClient()
  }

  private prepareStorage() {
    mkdirSync(this.storagePath, {recursive: true})
    mkdirSync(getCryptographyStoragePath(this.storagePath), {recursive: true})
  }

  private configureDependencyTokens() {
    container.registerInstance(WIRE_API_HOST, this.apiHost)
    container.registerInstance(WIRE_SDK_API_TOKEN, this.apiToken)
    container.registerInstance(WIRE_CRYPTOGRAPHY_STORAGE_KEY, this.cryptographyStorageKey)
    container.registerInstance(WIRE_STORAGE_PATH, this.storagePath)

    container.registerInstance(WIRE_EVENTS_HANDLER, this.wireEventsHandler)
  }

  private resolveRuntimeDependencies() {
    this.webSocketClient = container.resolve(WebSocketClient)
    this.conversationService = container.resolve(ConversationService)
  }

  private async configureApplicationIdentity() {
    const selfService = container.resolve(SelfService)
    await selfService.fetchAndSaveApplicationData()
  }

  private async initCryptoClient() {
    const coreCryptoService = container.resolve(CoreCryptoService)
    await coreCryptoService.initCoreCryptoClient()
    await coreCryptoService.initOrRegisterClient()

    this.logger.info(`CoreCrypto initialized.`)
  }

  async startListening() {
    if (this.isWebSocketRunning) {
      this.logger.info('Wire Apps SDK is already running.')
      return
    }
    this.isWebSocketRunning = true

    if (!this.webSocketClient || !this.conversationService) {
      throw new UnknownError('Wire Apps SDK dependencies are not initialized.')
    }

    this.webSocketClient.connect().finally(() => {
      this.isWebSocketRunning = false
    })

    await this.conversationService.establishOrRejoinConversations()
  }

  stopListening() {
    if (!this.isWebSocketRunning) {
      this.logger.info('Wire Apps SDK is not running.')
    }
    this.logger.info('Wire Apps SDK shutting down.')
    this.isWebSocketRunning = false

    this.webSocketClient?.close()
  }

  async close() {
    this.removeExitHandlers()

    this.logger.debug('Closing Websocket connections.')
    this.stopListening()

    this.logger.debug('Closing Database connections.')
    try {
      const databaseService = container.resolve(DatabaseService)
      databaseService.close()
    } catch (exception) {
      this.logger.debug('Database service was not initialized or could not be closed.', exception)
    }

    // Clear container to prevent memory leaks
    container.clearInstances()
  }

  /**
   * Registers a listener to be notified when the connection to the Wire backend
   * is established or lost.
   */
  setBackendConnectionListener(listener: BackendConnectionListener): void {
    this.webSocketClient?.setBackendConnectionListener(listener)
  }

  /**
   * Returns the WireApplicationManager used to interact with the Wire backend.
   *
   * Available as soon as create() resolves. Operations on MLS conversations require the app
   * to have joined those conversations, which happens during startListening().
   * Do not use the returned instance after close().
   */
  getApplicationManager(): WireApplicationManager {
    return container.resolve(WireApplicationManager)
  }

  private registerExitHandlers(): void {
    if (!this.shouldRegisterExitHandlers) {
      return
    }

    process.on('SIGINT', this.onSigint)
    process.on('SIGTERM', this.onSigterm)
    process.on('uncaughtException', this.onUncaughtException)
    process.on('unhandledRejection', this.onUnhandledRejection)
  }

  // Removing a listener that was never added is a no-op, so this is safe to call at any time
  private removeExitHandlers(): void {
    process.off('SIGINT', this.onSigint)
    process.off('SIGTERM', this.onSigterm)
    process.off('uncaughtException', this.onUncaughtException)
    process.off('unhandledRejection', this.onUnhandledRejection)
  }

  private async handleExit(signal: string, exitCode: number): Promise<void> {
    if (this.isShuttingDown) {
      return
    }

    this.isShuttingDown = true
    this.logger.info(`Received ${signal}, cleaning up...`)

    try {
      await this.close()
      this.logger.info('Cleanup completed successfully')
      process.exit(exitCode)
    } catch (exception) {
      this.logger.error('Error during cleanup:', exception)
      process.exit(1)
    }
  }
}
