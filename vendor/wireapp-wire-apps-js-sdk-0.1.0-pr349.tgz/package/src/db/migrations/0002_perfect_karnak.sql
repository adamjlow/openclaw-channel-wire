ALTER TABLE `conversation` ADD `message_timer` integer DEFAULT NULL;
