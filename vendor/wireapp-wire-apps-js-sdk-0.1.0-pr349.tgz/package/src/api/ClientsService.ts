/*
 * Wire
 * Copyright (C) 2025 Wire Swiss GmbH
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see http://www.gnu.org/licenses/.
 */

import type {MlsPublicKeys} from '../model/MlsPublicKeys.js'
import {ClientsApiClient} from './ClientsApiClient.js'
import {PreKeyCrypto} from '../model/PreKeyCrypto.js'
import {singleton} from 'tsyringe'

@singleton()
export class ClientsService {
  constructor(private clientsApiClient: ClientsApiClient) {}

  async registerClient(proteusPreKeys: PreKeyCrypto[], proteusLastPreKey: PreKeyCrypto): Promise<string> {
    return await this.clientsApiClient.registerClient(proteusPreKeys, proteusLastPreKey)
  }

  async updateClientWithMlsPublicKey(mlsPublicKeys: MlsPublicKeys): Promise<void> {
    await this.clientsApiClient.updateClientWithMlsPublicKey(mlsPublicKeys)
  }
}
